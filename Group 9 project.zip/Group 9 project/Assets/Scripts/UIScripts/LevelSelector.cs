using System;
using UnityEngine;
using UnityEngine.SceneManagement;


public class LevelSelector: MonoBehaviour
{
    public int jungLevel;
    public int tempLevel;


    public void LoadTemple()
    {
        SceneManager.LoadScene("Temple" + tempLevel);
    }

    public void LoadJungle()
    {
        SceneManager.LoadScene("Jungle" + jungLevel);
    }
}
