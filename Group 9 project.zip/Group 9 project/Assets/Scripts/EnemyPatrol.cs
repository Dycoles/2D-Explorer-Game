using UnityEngine;

public class EnemyPatrol : MonoBehaviour
{
    public float moveSpeed = 2f;          
    public float patrolDistance = 5f;      
    public Transform groundCheck;           
    public LayerMask groundLayer;           
    public Animator animator;                
    private Vector3 startPoint;
    private Vector3 endPoint;
    private bool movingRight = true;

    private void Start()
    {
        startPoint = transform.position;
        endPoint = startPoint + new Vector3(patrolDistance, 0, 0);
    }

    private void Update()
    {
        Move();

        // Check for ground to prevent falling off edges
        if (!IsGrounded())
        {
            TurnAround();
        }
    }

    private void Move()
    {
        Vector3 targetPoint = movingRight ? endPoint : startPoint;

        // Move towards the target point
        transform.position = Vector3.MoveTowards(transform.position, targetPoint, moveSpeed * Time.deltaTime);

        // Check if the enemy has reached the target point
        if (Vector3.Distance(transform.position, targetPoint) < 0.1f)
        {
            TurnAround();
        }
    }

    private void TurnAround()
    {
        movingRight = !movingRight;

        // Update the end point based on the new direction
        endPoint = movingRight ? startPoint + new Vector3(patrolDistance, 0, 0) : startPoint;

        // Optional: Flip the sprite to face the new direction
        Vector3 localScale = transform.localScale;
        localScale.x *= -1;  // Flip the enemy sprite
        transform.localScale = localScale;
    }

    private bool IsGrounded()
    {
        // Cast a ray downwards to check for ground
        return Physics2D.Raycast(groundCheck.position, Vector2.down, 0.1f, groundLayer);
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        // Check if the player is colliding with the enemy
        if (collision.gameObject.CompareTag("Player"))
        {
            // Check if the player is falling (relative velocity indicates jump)
            if (collision.relativeVelocity.y < 0)
            {
                PlayDeathAnimation();
            }
        }
    }

    private void PlayDeathAnimation()
    {
        if (animator != null)
        {
            animator.SetTrigger("Die");
        }

        // Destroy the enemy after a short delay to allow the animation to play
        Destroy(gameObject, 0.5f); 
    }
}
