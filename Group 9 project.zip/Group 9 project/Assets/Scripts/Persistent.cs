using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//This code was taken from Game451- 2D Interactions Solutions by Drew Castalia.
public class Persistent : MonoBehaviour {
    public static Persistent objects;

    //public HealthDisplay healthDisplay;

    Dictionary<string, bool> savedBools = new();

    void Awake() {
        if( objects != null ) {
            Destroy( this.gameObject );
            return;
        }

        objects = this;
        DontDestroyOnLoad( this.gameObject );
    }

    public void Save( string key, bool value ) {
        if( !savedBools.TryAdd( key, value ) ) savedBools[ key ] = value;
    }

    public bool Load( string key, bool defaultValue ) {
        return savedBools.GetValueOrDefault( key, defaultValue );
    }
}