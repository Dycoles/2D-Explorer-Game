using UnityEngine;

public class PlayerAudioManager : MonoBehaviour
{
    public AudioSource playerSfx;
    public AudioClip grassStep;
    public AudioClip woodStep;
    public AudioClip stoneStep;

    public AudioClip glide;
    public AudioClip transform;
    public AudioClip jump;
    public AudioClip slither;
    public AudioClip flap;

    private string surface = "grass";

    private void Start()
    {
        playerSfx.Stop();
    }

    void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("GrassZone"))
        {
            surface = "grass";
        }
        else if (other.CompareTag("WoodZone"))
        {
            surface = "wood";
        } else if (other.CompareTag("StoneZone"))
        {
            surface = "stone";
        }
    }

    public void PlayFootStep()
    {
        playerSfx.loop = true;

        switch (surface)
        {
            case "grass":
                playerSfx.clip = grassStep;
                break;
            case "wood":
                playerSfx.clip = woodStep;
                break;
            case "stone":
                playerSfx.clip = stoneStep;
                break;
            default:
                playerSfx.clip = grassStep;
                break;
        }
        if (!playerSfx.isPlaying)
        {
            playerSfx.Play(); // Start playing the loop
        }
    }
    public void StopFootStep()
    {
        if (playerSfx.isPlaying && playerSfx.time >= playerSfx.clip.length - 0.1f)
        {
            playerSfx.Stop(); // Stop the sound if it's playing
        }
    }

    public void StopSlither()
    {
        if (playerSfx.isPlaying && playerSfx.time >= playerSfx.clip.length - 0.1f && playerSfx.clip == slither)
        {
            playerSfx.Stop(); // Stop the sound if it's playing
        }
    }
    public void StopGlide()
    {
        if (playerSfx.isPlaying && playerSfx.time >= playerSfx.clip.length - 0.1f && playerSfx.clip == glide)
        {
            playerSfx.Stop(); // Stop the sound if it's playing
        }
    }
    public void StopFlap()
    {
        if (playerSfx.isPlaying && playerSfx.time >= playerSfx.clip.length - 0.1f && playerSfx.clip == flap)
        {
            playerSfx.Stop(); // Stop the sound if it's playing
        }
    }



    private void StopCurrentClip()
    {
        if (playerSfx.isPlaying)
        {
            playerSfx.Stop();
        }
    }


    public void PlayJump()
    {
        StopCurrentClip(); // Stop any currently playing clip
        playerSfx.clip = jump;
        playerSfx.loop = false; // Ensure it does not loop
        playerSfx.Play();
    }

    public void PlayGlide()
    {
        if (!playerSfx.isPlaying) // Only play if not already playing
        {
            playerSfx.clip = glide; // Set the clip only once
            playerSfx.loop = true; // Enable looping
            playerSfx.Play(); // Start playing the loop
        }
    }

    public void PlayFlap()
    {
        playerSfx.loop = true;
        playerSfx.clip = flap;

        if (!playerSfx.isPlaying)
        {
            playerSfx.Play();
        }
    }

    public void PlayTransform()
    {
        StopCurrentClip();
        playerSfx.clip = transform;
        playerSfx.loop = false;
        playerSfx.PlayOneShot(transform);
    }

    public void PlaySlither()
    {

        if (!playerSfx.isPlaying)
        {
            playerSfx.loop = true;
            playerSfx.clip = slither;
            playerSfx.Play();
        }
    }


}
