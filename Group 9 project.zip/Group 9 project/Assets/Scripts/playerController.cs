using UnityEngine;
using UnityEngine.InputSystem;

public class playerController : MonoBehaviour
{
    public GameObject humanObject;
    public GameObject monkeyObject;
    public GameObject snakeObject;
    public GameObject birdObject;
    private Animator humanAnimator;
    private Animator monkeyAnimator;
    private Animator snakeAnimator;
    private Animator birdAnimator;
    private PlayerAudioManager audioManager;

    private Rigidbody2D body;
    private SpriteRenderer spriteRenderer;
    // Character can be human, monkey, snake, or bird
    private enum Character { Human, Monkey, Snake, Bird };
    // thisCharacter refers to the selected character 
    private Character thisCharacter;

    public float speed;
    public float jump;

    private Vector2 position;
    private Vector2 velocity;
    private bool isJumping;
    private bool secondJump;

    // start as a human
    private void Start()
    {
        position = transform.position;
        SelectCharacter(Character.Human);
        audioManager = GetComponent<PlayerAudioManager>();
    }

    // cycle to another character
    private void SwitchChar()
    {
        // store position
        position = body.position;
        velocity = body.linearVelocity;

        // Cycle through characters
        if (thisCharacter == Character.Human)
        {
            SelectCharacter(Character.Monkey);
        }
        else if (thisCharacter == Character.Monkey)
        {
            SelectCharacter(Character.Snake);
        }
        else if (thisCharacter == Character.Snake)
        {
            SelectCharacter(Character.Bird);
        }
        else
        {
            SelectCharacter(Character.Human);
        }
    }

    private void SelectCharacter(Character characterType)
    {
        thisCharacter = characterType;

        // Enable/disable character forms if the character type matches the character in the enum
        humanObject.SetActive(characterType == Character.Human);
        monkeyObject.SetActive(characterType == Character.Monkey);
        snakeObject.SetActive(characterType == Character.Snake);
        birdObject.SetActive(characterType == Character.Bird);

        // Update the Rigidbody2D reference based on the active character
        switch (thisCharacter)
        {
            case Character.Human:
                body = humanObject.GetComponent<Rigidbody2D>();
                spriteRenderer = humanObject.GetComponent<SpriteRenderer>();
                humanAnimator = humanObject.GetComponent<Animator>();
                break;
            case Character.Monkey:
                body = monkeyObject.GetComponent<Rigidbody2D>();
                spriteRenderer = monkeyObject.GetComponent<SpriteRenderer>();
                monkeyAnimator = monkeyObject.GetComponent<Animator>();
                break;
            case Character.Snake:
                body = snakeObject.GetComponent<Rigidbody2D>();
                spriteRenderer = snakeObject.GetComponent<SpriteRenderer>();
                snakeAnimator = snakeObject.GetComponent<Animator>();
                break;
            case Character.Bird:
                body = birdObject.GetComponent<Rigidbody2D>();
                spriteRenderer = birdObject.GetComponent<SpriteRenderer>();
                birdAnimator = birdObject.GetComponent<Animator>();
                break;
        }
        // update position after switching character
        //body.position = position;
    }

    private void HumanController()
    {
        Debug.Log("Controlling Human");
        Vector2 movementInput = InputSystem.actions["Move"].ReadValue<Vector2>();
        // only move horizontally
        movementInput = new Vector2(movementInput.x, 0);
        body.linearVelocity = new Vector2(movementInput.x * speed, body.linearVelocity.y);
        if (body.linearVelocity.magnitude > 0.1f && IsGrounded())
        {
            humanAnimator.SetBool("isWalking", true);
            audioManager.PlayFootStep();
        } else
        {
            humanAnimator.SetBool("isWalking", false);
            audioManager.StopFootStep();
        }
        if (IsGrounded())
        {
            humanAnimator.SetBool("isJumping", false);
        } else
        {
            humanAnimator.SetBool("isJumping", true);
        }

        if (movementInput.x > 0)
        {
            // Moving right
            spriteRenderer.flipX = false; // Face right
        }
        else if (movementInput.x < 0)
        {
            // Moving left
            spriteRenderer.flipX = true; // Face left
        }

        Vector2 feet = humanObject.GetComponent<Collider2D>().bounds.min;
        RaycastHit2D hit = Physics2D.Raycast(feet, Vector2.down, 0.1f);
        if (hit.collider)
        {
            Debug.DrawLine(feet, hit.point, Color.green);
            Debug.Log($"I'm standing on {hit.collider}");
            if (InputSystem.actions["Jump"].WasPressedThisFrame())
            {
                body.AddForce(Vector2.up * jump, ForceMode2D.Impulse);
                audioManager.PlayJump();
            }

        }
        else
        {
            Debug.DrawLine(feet, feet + Vector2.down * 0.1f, Color.red);
            Debug.Log("I'm not standing on anything...");
        }
    }


    private void MonkeyController()
    {
        Debug.Log("Controlling Monkey");
        Vector2 movementInput = InputSystem.actions["Move"].ReadValue<Vector2>();
        // only move horizontally
        movementInput = new Vector2(movementInput.x, 0);
        body.linearVelocity = new Vector2(movementInput.x * speed, body.linearVelocity.y);

        if (movementInput.x > 0)
        {
            // Moving right
            spriteRenderer.flipX = false; // Face right
        }
        else if (movementInput.x < 0)
        {
            // Moving left
            spriteRenderer.flipX = true; // Face left
        }
        Vector2 feet = monkeyObject.GetComponent<Collider2D>().bounds.min;
        RaycastHit2D hit = Physics2D.Raycast(feet, Vector2.down, 0.1f);
        if (body.linearVelocity.magnitude > 0.1f && IsGrounded() && hit.collider)
        {
            monkeyAnimator.SetBool("isWalking", true);
            audioManager.PlayFootStep();
        }
        else
        {
            monkeyAnimator.SetBool("isWalking", false);
            audioManager.StopFootStep();
        }
        if (hit.collider)
        {
            Debug.DrawLine(feet, hit.point, Color.green);
            Debug.Log($"I'm standing on {hit.collider}");
            monkeyAnimator.SetBool("isJumping", false);
        }
        else
        {
            Debug.DrawLine(feet, feet + Vector2.down * 0.1f, Color.red);
            Debug.Log("I'm not standing on anything...");
            monkeyAnimator.SetBool("isJumping", true);
        }

        if (IsGrounded())
        {
            if (InputSystem.actions["Jump"].WasPressedThisFrame())
            {
                body.AddForce(Vector2.up * jump, ForceMode2D.Impulse);
                audioManager.PlayJump();
            }
            secondJump = false;
        }
        else
        {
            // Allow double jump if not grounded and first jump has been used
            if (!secondJump)
            {
                if (InputSystem.actions["Jump"].WasPressedThisFrame())
                {
                    body.AddForce(Vector2.up * jump, ForceMode2D.Impulse);
                    secondJump = true; // Set secondJump to true after the jump
                    audioManager.PlayJump();
                }
            }
        }
    }



    private bool IsGrounded()
    {
        return body.linearVelocity.y < 0.001 && body.linearVelocity.y > -0.001;
    }

    private void BirdController()
    {
        Debug.Log("Controlling Bird");
        Vector2 movementInput = InputSystem.actions["Move"].ReadValue<Vector2>();
        // only move horizontally
        movementInput = new Vector2(movementInput.x, 0);
        body.linearVelocity = new Vector2(movementInput.x * speed, body.linearVelocity.y);

        if (movementInput.x > 0)
        {
            // Moving right
            spriteRenderer.flipX = false; // Face right
        }
        else if (movementInput.x < 0)
        {
            // Moving left
            spriteRenderer.flipX = true; // Face left
        }

        Vector2 feet = birdObject.GetComponent<Collider2D>().bounds.min;
        RaycastHit2D hit = Physics2D.Raycast(feet, Vector2.down, 0.1f);
        if (hit.collider)
        {
            Debug.DrawLine(feet, hit.point, Color.green);
            Debug.Log($"I'm standing on {hit.collider}");
            if (InputSystem.actions["Jump"].WasPressedThisFrame())
            {
                {
                    body.AddForce(Vector2.up * jump, ForceMode2D.Impulse);
                    isJumping = true;
                    audioManager.PlayJump();
                }

            }
            else
            {
                Debug.DrawLine(feet, feet + Vector2.down * 0.1f, Color.red);
                Debug.Log("I'm not standing on anything...");
                isJumping = false;
            }
        }
        // add logic to have bird glide
        float currentVerticalVelocity = body.linearVelocity.y;
        if (body.linearVelocity.magnitude > 0 && IsGrounded())
        {
            birdAnimator.SetBool("isWalking", true);
            audioManager.PlayFlap();
        }
        else
        {
            birdAnimator.SetBool("isWalking", false);
            audioManager.StopFlap();
        }
        if (IsGrounded())
        {
            birdAnimator.SetBool("isJumping", false);
        }
        else
        {
            birdAnimator.SetBool("isJumping", true);
            if(!InputSystem.actions["Jump"].IsPressed())
            {
                audioManager.PlayFlap();
            }
        }

        // Check if the bird is falling and that space is being held
        if (currentVerticalVelocity < 0 && InputSystem.actions["Jump"].IsPressed())
        {
            Debug.Log("Flying");
            body.gravityScale = 0.1f;
            birdAnimator.SetBool("isGliding", true);
            audioManager.PlayGlide();
        }
        else
        {
            body.gravityScale = 1.0f;
            birdAnimator.SetBool("isGliding", false);
            audioManager.StopGlide();
        }
    }

    private void SnakeController()
    {
        Debug.Log("Controlling Snake");
        Vector2 movementInput = InputSystem.actions["Move"].ReadValue<Vector2>();
        // only move horizontally
        movementInput = new Vector2(movementInput.x, 0);
        body.linearVelocity = new Vector2(movementInput.x * speed, body.linearVelocity.y);

        if (movementInput.x > 0)
        {
            // Moving right
            spriteRenderer.flipX = false; // Face right
        }
        else if (movementInput.x < 0)
        {
            // Moving left
            spriteRenderer.flipX = true; // Face left
        }

        if (body.linearVelocity.magnitude > 0.1f && IsGrounded())
        {
            snakeAnimator.SetBool("isWalking", true);
            audioManager.PlaySlither();
        }
        else
        {
            snakeAnimator.SetBool("isWalking", false);
            audioManager.StopSlither();
        }
        // snake cannot jump
    }


    void Update()
    {
        if (InputSystem.actions["Interact"].WasPressedThisFrame())
        {
            // press E to switch characters
            SwitchChar();
            audioManager.PlayTransform();
        }

        if (thisCharacter == Character.Human)
        {
            HumanController();
        }
        else if (thisCharacter == Character.Monkey)
        {
            MonkeyController();
        }
        else if (thisCharacter == Character.Bird)
        {
            BirdController();
        }
        else
        {
            SnakeController();
        }
        UpdateInactiveCharacterStates();

    }
    private void UpdateInactiveCharacterStates()
    {
        Vector2 activeCharacterPosition = body.position;
        Vector2 activeCharacterVelocity = body.linearVelocity;

        if (thisCharacter != Character.Human)
        {
            Rigidbody2D humanBody = humanObject.GetComponent<Rigidbody2D>();
            humanObject.transform.position = activeCharacterPosition;
            humanBody.linearVelocity = activeCharacterVelocity;
        }
        if (thisCharacter != Character.Monkey)
        {
            Rigidbody2D monkeyBody = monkeyObject.GetComponent<Rigidbody2D>();
            monkeyObject.transform.position = activeCharacterPosition;
            monkeyBody.linearVelocity = activeCharacterVelocity;
        }
        if (thisCharacter != Character.Bird)
        {
            Rigidbody2D birdBody = birdObject.GetComponent<Rigidbody2D>();
            birdObject.transform.position = activeCharacterPosition;
            birdBody.linearVelocity = activeCharacterVelocity;
        }
        if (thisCharacter != Character.Snake)
        {
            Rigidbody2D snakeBody = snakeObject.GetComponent<Rigidbody2D>();
            snakeObject.transform.position = activeCharacterPosition;
            snakeBody.linearVelocity = activeCharacterVelocity;
        }
    }
}


